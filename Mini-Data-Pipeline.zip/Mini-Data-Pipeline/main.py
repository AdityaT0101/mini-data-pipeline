import pandas as pd

df = pd.read_csv('users.csv')
print(df.head())
